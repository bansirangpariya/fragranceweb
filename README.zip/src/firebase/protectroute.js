import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getAuth } from "firebase/auth";

const ProtectedRoute = ({ children }) => {
  const auth = getAuth();
  const user = auth.currentUser;
  const navigate = useNavigate();
  // console.log(user, "useruseruseruseruser");
  useEffect(() => {
    if (!user?.uid) {
      // navigate("/signin");
    }
  }, [user]);

  return children;
};

export default ProtectedRoute;
