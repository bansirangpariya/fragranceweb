import React, { useEffect, useState } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import axios from "axios";

const Product = () => {
  // Initialize AOS
  useEffect(() => {
    AOS.init({
      duration: 1200, // Animation duration
      easing: "ease-in-out", // Easing function
      once: false, // Allow animations to repeat on reverse scroll
      delay: 100, // Delay for elements
    });
  }, []);

  const [perfumeDetails, setPerfumeDetails] = useState([]);

  const options = {
    method: "GET",
    url: "http://localhost:8000/api/perfume/get-perfume",
  };

  useEffect(() => {
    axios
      // .get("https://dummyjson.com/products/categories")
      .request(options)
      .then((response) => {
        setPerfumeDetails(response.data);
        console.log(response, "--------------resfasdfadf");
      })
      .catch((error) => {
        console.error("Error fetching categories:", error);
      });
  }, []);

  // const perfumeDetails = [
  //   // {
  //   //   id: 1,
  //   //   img: "perfume-1.png",
  //   //   title: "Cool Winters",
  //   //   description: "Lorem ipsum dolor sit amet, consectetur adipiscing.",
  //   //   btn: "Discover More",
  //   // },
  //   // {
  //   //   id: 2,
  //   //   img: "perfume-2.png",
  //   //   title: "Eu De Rose",
  //   //   description: "Lorem ipsum dolor sit amet, consectetur adipiscing.",
  //   //   btn: "Discover More",
  //   // },
  //   // {
  //   //   id: 3,
  //   //   img: "perfume-3.png",
  //   //   title: "Warm Sakura",
  //   //   description: "Lorem ipsum dolor sit amet, consectetur adipiscing.",
  //   //   btn: "Discover More",
  //   // },
  //   {
  //     id: 0,
  //     image: "https://fimgs.net/mdimg/perfume/375x500.71653.jpg",
  //     perfume: "My Way Nacre Giorgio Armani for women",
  //     brand: "giorgio armani perfumes and colognes",
  //     notesPercentage: "85.71428571428571",
  //     description:
  //       "My Way Nacre by Giorgio Armani is a fragrance for women. This is a new fragrance. My Way Nacre was launched in 2022. Top notes are Orange Blossom and Bergamot; middle notes are Tuberose and Jasmine; base notes are Cedar, Vanilla and White Musk.",
  //   },
  //   {
  //     id: 1,
  //     image: "https://fimgs.net/mdimg/perfume/375x500.71653.jpg",
  //     perfume: "My Way Nacre Giorgio Armani for women",
  //     brand: "giorgio armani perfumes and colognes",
  //     notesPercentage: "85.71428571428571",
  //     description:
  //       "My Way Nacre by Giorgio Armani is a fragrance for women. This is a new fragrance. My Way Nacre was launched in 2022. Top notes are Orange Blossom and Bergamot; middle notes are Tuberose and Jasmine; base notes are Cedar, Vanilla and White Musk.",
  //   },
  //   {
  //     id: 2,
  //     image: "https://fimgs.net/mdimg/perfume/375x500.71653.jpg",
  //     perfume: "My Way Nacre Giorgio Armani for women",
  //     brand: "giorgio armani perfumes and colognes",
  //     notesPercentage: "85.71428571428571",
  //     description:
  //       "My Way Nacre by Giorgio Armani is a fragrance for women. This is a new fragrance. My Way Nacre was launched in 2022. Top notes are Orange Blossom and Bergamot; middle notes are Tuberose and Jasmine; base notes are Cedar, Vanilla and White Musk.",
  //   },
  //   {
  //     id: 3,
  //     image: "https://fimgs.net/mdimg/perfume/375x500.71653.jpg",
  //     perfume: "My Way Nacre Giorgio Armani for women",
  //     brand: "giorgio armani perfumes and colognes",
  //     notesPercentage: "85.71428571428571",
  //     description:
  //       "My Way Nacre by Giorgio Armani is a fragrance for women. This is a new fragrance. My Way Nacre was launched in 2022. Top notes are Orange Blossom and Bergamot; middle notes are Tuberose and Jasmine; base notes are Cedar, Vanilla and White Musk.",
  //   },
  // ];

  return (
    <>
      <div className="space-y-10 bg-[#262626] py-28">
        <div className="text-center animate-fade-in" data-aos="fade-up">
          <h1 className="text-xl md:text-3xl lg:text-6xl font-bold text-transparent stroke-text opacity-90">
            Perfume
          </h1>
          <h1 className="text-lg md:text-3xl lg:text-5xl font-bold text-white opacity-90">
            Find your Perfume
          </h1>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-14 max-w-7xl mx-auto px-4">
          {perfumeDetails.map((val) => (
            <div
              className="bg-[#2F2F30] animate-fade-in justify-center text-center rounded-full py-14 px-10 space-y-6 h-auto w-full"
              key={val.id}
              data-aos="fade-up"
              data-aos-delay={val.id * 100}
            >
              <img
                src={val.img}
                alt={val.title}
                className="w-[60%] mx-auto h-56 object-contain"
              />
              <h1 className="text-white text-2xl lg:text-3xl font-semibold">
                {val.title}
              </h1>
              <p className="text-gray-300 text-sm lg:text-lg font-normal opacity-90">
                {val.description}
              </p>
              <button
                type="button"
                className="mt-4 text-white border border-white hover:border-[#F2C437] hover:text-[#F2C437] focus:ring-4 focus:outline-none focus:ring-gray-300 font-semibold rounded-full text-sm lg:text-base px-6 py-3"
              >
                {val.btn}
              </button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Product;
